#!/bin/bash
CONVERT="java -jar ../../bin/gen.jar -convertToScip"
ZIMPL="../../bin/zimpl"
KNAP="../../mip/scip/knap-v3.zpl"
for f in ??/*.json
do
	zpl=${f/.json/.zpl}
	lp=${f/.json/}
	d=`echo $zpl | cut -d '/' -f 1`
	n=`echo ${zpl/.zpl/} | cut -d '/' -f 2`
	#$CONVERT $f > $zpl
	$ZIMPL $zpl -t lp
	mv $n.lp $d
	rm $n.tbl
done

